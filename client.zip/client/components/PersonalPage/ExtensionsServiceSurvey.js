import React from "react";
import { View, Text } from "react-native";

const ExtensionsServiceSurvey = () => {
    <View>
        <Text>HELLO</Text>
    </View>
};
export default ExtensionsServiceSurvey;